/*
* Compute visible graph of a set S of disjoint polygonal obstacles and two points p and q
* @para obstacles, a set of disjoint polygonal obstacles
* @para p, start point
* @para q, end point
*/

var obstacles = [
    [ [46, -36], [130,34], [-88, 69], [-85,-21] ],
    [ [400, 100], [600, 400], [800, 200] ],
    [ [900, 200], [1000, 600], [1200, 200] ]
];


function naiveVisibleGraph(obstacles, p, q) {
    
    // compute all vertices
    var vertexes = new Array();
    
    obstacles.forEach(function(obstacle) {
        obstacle.forEach(function(point) {
            vertexes.push(point);           
            
        });
    });
    
    console.log(vertexes);
    
    
    
}